package mr

import "fmt"
import "log"
import "net/rpc"
import "hash/fnv"
import "time"
import "os"
import "io/ioutil"
import "encoding/json"
import "sort"
import "strings"


//
// Map functions return a slice of KeyValue.
//
type KeyValue struct {
	Key   string
	Value string
}

//
// use ihash(key) % NReduce to choose the reduce
// task number for each KeyValue emitted by Map.
//
func ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}


//
// main/mrworker.go calls this function.
//
func Worker(mapf func(string, string) []KeyValue,
    reducef func(string, []string) string) {

    for {
        ok := workerStep(mapf, reducef)
        if !ok {
            return
        }
    }

	// uncomment to send the Example RPC to the coordinator.
	// CallExample()

}
// aq ideashi workerma rac unda gaaketos titoeul shemtxvevashi egaa, nu cota dekompozicia maq tore bevri kodi gamodioda
func workerStep(mapf func(string, string) []KeyValue, reducef func(string, []string) string) bool {
    args := RequestTaskArgs{}
    reply := RequestTaskReply{}
    ok := call("Coordinator.RequestTask", &args, &reply)
    if !ok {
        return false
    }
    t := reply.Type
    if t == TaskWait {
        time.Sleep(200 * time.Millisecond)
        return true
    }
    if t == TaskExit {
        return false
    }
    if t == TaskMap {
        if len(reply.Filenames) > 0 {
            doMap(reply.MapID, reply.Filenames[0], reply.NReduce, mapf)
        }
        a := ReportTaskArgs{Type: TaskMap, MapID: reply.MapID, At: time.Now()}
        r := ReportTaskReply{}
        call("Coordinator.ReportTask", &a, &r)
        return true
    }
    if t == TaskReduce {
        doReduce(reply.ReduceID, reply.NReduce, reducef)
        a := ReportTaskArgs{Type: TaskReduce, ReduceID: reply.ReduceID, At: time.Now()}
        r := ReportTaskReply{}
        call("Coordinator.ReportTask", &a, &r)
        return true
    }
    time.Sleep(100 * time.Millisecond)
    return true
}

func doMap(mapID int, filename string, nReduce int, mapf func(string, string) []KeyValue) {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return
    }
    kva := mapf(filename, string(data))
    buckets := make([][]KeyValue, nReduce)
    for _, kv := range kva {
        r := ihash(kv.Key) % nReduce
        buckets[r] = append(buckets[r], kv)
    }
    for r := 0; r < nReduce; r++ {
        writePart(mapID, r, buckets[r])
    }
}

func writePart(mapID int, reduceID int, kvs []KeyValue) {
    tmp, err := ioutil.TempFile(".", "mr-tmp-")
    if err != nil {
        return
    }
    enc := json.NewEncoder(tmp)
    for _, kv := range kvs {
        _ = enc.Encode(&kv)
    }
    tmp.Close()
    final := partName(mapID, reduceID)
    os.Rename(tmp.Name(), final)
}

func partName(mapID int, reduceID int) string {
    return fmt.Sprintf("mr-%d-%d", mapID, reduceID)
}

func doReduce(reduceID int, nReduce int, reducef func(string, []string) string) {
    var kvs []KeyValue
    files, _ := ioutil.ReadDir(".")
    for _, f := range files {
        name := f.Name()
        if strings.HasPrefix(name, "mr-") && strings.HasSuffix(name, fmt.Sprintf("-%d", reduceID)) {
            readPart(name, &kvs)
        }
    }
    groups := make(map[string][]string)
    for _, kv := range kvs {
        groups[kv.Key] = append(groups[kv.Key], kv.Value)
    }
    keys := make([]string, 0, len(groups))
    for k := range groups {
        keys = append(keys, k)
    }
    sort.Strings(keys)
    tmp, err := ioutil.TempFile(".", "mr-out-tmp-")
    if err != nil {
        return
    }
    for _, k := range keys {
        v := reducef(k, groups[k])
        fmt.Fprintf(tmp, "%v %v\n", k, v)
    }
    tmp.Close()
    final := fmt.Sprintf("mr-out-%d", reduceID)
    os.Rename(tmp.Name(), final)
}

func readPart(path string, out *[]KeyValue) {
    f, err := os.Open(path)
    if err != nil {
        return
    }
    defer f.Close()
    dec := json.NewDecoder(f)
    for {
        var kv KeyValue
        if err := dec.Decode(&kv); err != nil {
            break
        }
        *out = append(*out, kv)
    }
}

//
// example function to show how to make an RPC call to the coordinator.
//
// the RPC argument and reply types are defined in rpc.go.
//
func CallExample() {

	// declare an argument structure.
	args := ExampleArgs{}

	// fill in the argument(s).
	args.X = 99

	// declare a reply structure.
	reply := ExampleReply{}

	// send the RPC request, wait for the reply.
	// the "Coordinator.Example" tells the
	// receiving server that we'd like to call
	// the Example() method of struct Coordinator.
	ok := call("Coordinator.Example", &args, &reply)
	if ok {
		// reply.Y should be 100.
		fmt.Printf("reply.Y %v\n", reply.Y)
	} else {
		fmt.Printf("call failed!\n")
	}
}

//
// send an RPC request to the coordinator, wait for the response.
// usually returns true.
// returns false if something goes wrong.
//
func call(rpcname string, args interface{}, reply interface{}) bool {
	// c, err := rpc.DialHTTP("tcp", "127.0.0.1"+":1234")
	sockname := coordinatorSock()
	c, err := rpc.DialHTTP("unix", sockname)
	if err != nil {
		log.Fatal("dialing:", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err == nil {
		return true
	}

	fmt.Println(err)
	return false
}
