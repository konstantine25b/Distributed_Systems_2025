package mr

import "log"
import "net"
import "os"
import "net/rpc"
import "net/http"
import "sync"
import "time"


type Coordinator struct {
    mu       sync.Mutex
    nReduce  int
    files    []string
    mapTasks []int
    mapTime  []time.Time
    reduceTasks []int
    reduceTime  []time.Time
    phase    int

}

// Your code here -- RPC handlers for the worker to call.

func (c *Coordinator) RequestTask(args *RequestTaskArgs, reply *RequestTaskReply) error {
    c.mu.Lock()
    defer c.mu.Unlock()
    c.refresh()
    if c.phase == 0 {
        if c.giveMap(reply) {
            return nil
        }
        if !c.allDone(c.mapTasks) {
            c.setWait(reply)
            return nil
        }
        c.phase = 1
    }
    if c.phase == 1 {
        if c.giveReduce(reply) {
            return nil
        }
        if !c.allDone(c.reduceTasks) {
            c.setWait(reply)
            return nil
        }
        c.phase = 2
    }
    reply.Type = TaskExit
    return nil
}

func (c *Coordinator) ReportTask(args *ReportTaskArgs, reply *ReportTaskReply) error {
    c.mu.Lock()
    defer c.mu.Unlock()
    if args.Type == TaskMap {
        c.finishMap(args.MapID)
    } else if args.Type == TaskReduce {
        c.finishReduce(args.ReduceID)
    }
    return nil
}

//
// an example RPC handler.
//
// the RPC argument and reply types are defined in rpc.go.
//
func (c *Coordinator) Example(args *ExampleArgs, reply *ExampleReply) error {
	reply.Y = args.X + 1
	return nil
}


//
// start a thread that listens for RPCs from worker.go
//
func (c *Coordinator) server() {
	rpc.Register(c)
	rpc.HandleHTTP()
	//l, e := net.Listen("tcp", ":1234")
	sockname := coordinatorSock()
	os.Remove(sockname)
	l, e := net.Listen("unix", sockname)
	if e != nil {
		log.Fatal("listen error:", e)
	}
	go http.Serve(l, nil)
}

//
// main/mrcoordinator.go calls Done() periodically to find out
// if the entire job has finished.
//
func (c *Coordinator) Done() bool {
    c.mu.Lock()
    defer c.mu.Unlock()
    return c.phase == 2
}

//
// create a Coordinator.
// main/mrcoordinator.go calls this function.
// nReduce is the number of reduce tasks to use.
//
func MakeCoordinator(files []string, nReduce int) *Coordinator {
    c := Coordinator{nReduce: nReduce}
    c.files = make([]string, len(files))
    copy(c.files, files)
    c.mapTasks = make([]int, len(files))
    c.mapTime = make([]time.Time, len(files))
    c.reduceTasks = make([]int, nReduce)
    c.reduceTime = make([]time.Time, nReduce)
    c.phase = 0
	c.server()
	return &c
}
// aq prosta gadavuyvevbit da vnaxvatdasrulda tu ara yvela taski
func (c *Coordinator) allDone(a []int) bool {
    for _, s := range a {
        if s != 2 {
            return false
        }
    }
    return true
}

func (c *Coordinator) pick(a []int) (int, bool) {
    for i, s := range a {
        if s == 0 {
            return i, true
        }
    }
    return -1, false
}

func (c *Coordinator) refresh() {
    now := time.Now()
    for i, s := range c.mapTasks {
        if s == 1 {
            if now.Sub(c.mapTime[i]) > 10*time.Second {
                c.mapTasks[i] = 0
            }
        }
    }
    for i, s := range c.reduceTasks {
        if s == 1 {
            if now.Sub(c.reduceTime[i]) > 10*time.Second {
                c.reduceTasks[i] = 0
            }
        }
    }
}

func (c *Coordinator) setWait(reply *RequestTaskReply) {
    reply.Type = TaskWait
    reply.NReduce = c.nReduce
}

func (c *Coordinator) giveMap(reply *RequestTaskReply) bool {
    id, ok := c.pick(c.mapTasks)
    if !ok {
        return false
    }
    c.mapTasks[id] = 1
    c.mapTime[id] = time.Now()
    reply.Type = TaskMap
    reply.MapID = id
    reply.NReduce = c.nReduce
    reply.Filenames = []string{c.files[id]}
    return true
}

func (c *Coordinator) giveReduce(reply *RequestTaskReply) bool {
    id, ok := c.pick(c.reduceTasks)
    if !ok {
        return false
    }
    c.reduceTasks[id] = 1
    c.reduceTime[id] = time.Now()
    reply.Type = TaskReduce
    reply.ReduceID = id
    reply.NReduce = c.nReduce
    return true
}

func (c *Coordinator) finishMap(id int) {
    if id < 0 || id >= len(c.mapTasks) {
        return
    }
    c.mapTasks[id] = 2
    if c.phase == 0 && c.allDone(c.mapTasks) {
        c.phase = 1
    }
}

func (c *Coordinator) finishReduce(id int) {
    if id < 0 || id >= len(c.reduceTasks) {
        return
    }
    c.reduceTasks[id] = 2
    if c.phase == 1 && c.allDone(c.reduceTasks) {
        c.phase = 2
    }
}
