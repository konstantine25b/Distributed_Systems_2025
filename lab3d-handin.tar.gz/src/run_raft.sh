#!/bin/bash

COUNT=${1:-1}          # default to 1 if not provided
RACEFLAG=${2:-""}      # pass "-race" here
PATTERN=${3:-""}       # optional test pattern

mkdir -p raft_copies

for i in {1..20}; do
  rm -rf raft_copies/raft1_copy$i
  cp -r raft1 raft_copies/raft1_copy$i
  (
    cd raft_copies/raft1_copy$i &&
    go test $RACEFLAG -run "$PATTERN" -count=$COUNT -timeout 0 > output.txt 2>&1
  ) &
done

wait
cat raft_copies/raft1_copy*/output.txt > raft_copies/all_outputs.txt
