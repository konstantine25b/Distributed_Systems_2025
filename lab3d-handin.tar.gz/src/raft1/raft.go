package raft

// The file raftapi/raft.go defines the interface that raft must
// expose to servers (or the tester), but see comments below for each
// of these functions for more details.
//
// Make() creates a new raft peer that implements the raft interface.

import (
	"bytes"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"6.5840/labgob"
	"6.5840/labrpc"
	"6.5840/raftapi"
	"6.5840/tester1"
)


// A Go object implementing a single Raft peer.
type Raft struct {
	mu        sync.Mutex          // Lock to protect shared access to this peer's state
	peers     []*labrpc.ClientEnd // RPC end points of all peers
	persister *tester.Persister   // Object to hold this peer's persisted state
	me        int                 // this peer's index into peers[]
	dead      int32               // set by Kill()

	// Your data here (3A, 3B, 3C).
	// Look at the paper's Figure 2 for a description of what
	// state a Raft server must maintain.

	currentTerm int 
	votedFor int
	log []LogEntry

	commitIndex int
	lastApplied int

	nextIndex []int // leader state anu vstoravt next log indexs
	matchIndex []int //highest log entry replicated

	serverState ServerState // candidate, follower, leader
	electionTimeoutDeadline time.Time 
	lastHeartbeatTime time.Time // 120ms shi iqneba xolme heartbeats
	votesReceivedInCurrentTerm int

	applyCh chan raftapi.ApplyMsg

	lastIncludedIndex int // bolo indexi bolo entrys romelic snapshotshia
	lastIncludedTerm int // bolo termi bolo lastIncludedIndexis romelic snapshots
	snapshotData []byte
}

type LogEntry struct {
	Term int
	Command interface{}
}

type ServerState int

const (
	Follower ServerState = iota
	Candidate
	Leader
)

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {

	var term int
	var isleader bool
	// Your code here (3A).
	rf.mu.Lock()
	defer rf.mu.Unlock()
	
	term = rf.currentTerm
	if rf.serverState == Leader {
		isleader = true
	} else {
		isleader = false
	}
	return term, isleader
}

// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
// before you've implemented snapshots, you should pass nil as the
// second argument to persister.Save().
// after you've implemented snapshots, pass the current snapshot
// (or nil if there's not yet a snapshot).
func (rf *Raft) persist() {
	// Your code here (3C).
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.currentTerm)
	e.Encode(rf.votedFor)
	_ = e.Encode(rf.lastIncludedIndex)
	_ = e.Encode(rf.lastIncludedTerm)
	_ = e.Encode(rf.log)
	raftstate := w.Bytes()
	rf.persister.Save(raftstate, rf.snapshotData)
}


// restore previously persisted state.
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	// Your code here (3C).
	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)
	var currentTerm int
	var votedFor int
	var lastIncludedIndex int
	var lastIncludedTerm int
	var log []LogEntry
	if d.Decode(&currentTerm) != nil ||
		d.Decode(&votedFor) != nil ||
		d.Decode(&lastIncludedIndex) != nil ||
		d.Decode(&lastIncludedTerm) != nil ||
		d.Decode(&log) != nil {
	} else {
		rf.currentTerm = currentTerm
		rf.votedFor = votedFor
		rf.lastIncludedIndex = lastIncludedIndex
		rf.lastIncludedTerm = lastIncludedTerm
		rf.log = log
	}
	rf.snapshotData = rf.persister.ReadSnapshot()
}

// how many bytes in Raft's persisted log?
func (rf *Raft) PersistBytes() int {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	return rf.persister.RaftStateSize()
}


// the service says it has created a snapshot that has
// all info up to and including index. this means the
// service no longer needs the log through (and including)
// that index. Raft should now trim its log as much as possible.
func (rf *Raft) Snapshot(index int, snapshot []byte) {
	// Your code here (3D).

	rf.mu.Lock()
	defer rf.mu.Unlock()

	if index <= rf.lastIncludedIndex {
		return
	}
	if index > rf.getLastLogIndex() {
		index = rf.getLastLogIndex()
	}

	termAtIndex := rf.getTermAtIndex(index)

	newLog := make([]LogEntry, 1)
	newLog[0] = LogEntry{Term: termAtIndex, Command: nil}
	for i := index + 1; i <= rf.getLastLogIndex(); i++ {
		newLog = append(newLog, rf.getEntryAtIndex(i))
	}
	// axali logit vanacvlebt dzvels 
	rf.log = newLog
	rf.lastIncludedIndex = index
	rf.lastIncludedTerm = termAtIndex

	if rf.commitIndex < rf.lastIncludedIndex {
		rf.commitIndex = rf.lastIncludedIndex
	}
	if rf.lastApplied < rf.lastIncludedIndex {
		rf.lastApplied = rf.lastIncludedIndex
	}

	rf.snapshotData = make([]byte, len(snapshot))
	copy(rf.snapshotData, snapshot)
	rf.persist()
}


// example RequestVote RPC arguments structure.
// field names must start with capital letters!
type RequestVoteArgs struct {
	// Your data here (3A, 3B).
	CandidateTerm int
	CandidateId int
	// ameebit vxvdebit rom kandidatad shegvilia shevarchiot tu ara
	LastLogIndexOfCandidate int
	LastLogTermOfCandidate int
}

// example RequestVote RPC reply structure.
// field names must start with capital letters!
type RequestVoteReply struct {
	// Your data here (3A).
	CurrentTerm int
	VoteGranted bool
}

// example RequestVote RPC handler.
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	// Your code here (3A, 3B).
	rf.mu.Lock()
	defer rf.mu.Unlock()

	reply.VoteGranted = false
	
	if args.CandidateTerm < rf.currentTerm {
		reply.CurrentTerm = rf.currentTerm
		reply.VoteGranted = false
		return
	}

	if args.CandidateTerm > rf.currentTerm {
		rf.currentTerm = args.CandidateTerm
		rf.serverState = Follower
		rf.votedFor = -1
		rf.persist()
	}
    // amiti vamowmeb rom kandidatis log minimum rf is logis xela mainc ikos
	candidateLogIsUpToDate := rf.checkIfCandidateLogIsUpToDate(args.LastLogIndexOfCandidate, args.LastLogTermOfCandidate)
    // aq jer vchekavt to xma gvaqvs tu ara micemuli, an meore varianti sheileba isev gvtxovos igive kandidatma xmis micema.
	if rf.votedFor == -1 || rf.votedFor == args.CandidateId {
		if candidateLogIsUpToDate {
			rf.votedFor = args.CandidateId
			rf.resetElectionTimeout()
			reply.VoteGranted = true
			rf.persist()
		}
	}

	reply.CurrentTerm = rf.currentTerm
}

type AppendEntriesArgs struct {
	LeaderTerm int
	LeaderId int
	PreviousLogIndex int
	PreviousLogTerm int
	Entries []LogEntry
	LeaderCommitIndex int
}

type AppendEntriesReply struct {
	CurrentTerm int
	Success bool
	// conflictebs viyenebvt rom tu logshi confliqtia liders pirdapir davexmarot sadaa problema magashi
	ConflictTerm int 
	ConflictIndex int
}

type InstallSnapshotArgs struct {
	Term int
	LeaderId int
	LastIncludedIndex int
	LastIncludedTerm int
	Snapshot []byte
}

type InstallSnapshotReply struct {
	Term int
}

func (rf *Raft) InstallSnapshot(args *InstallSnapshotArgs, reply *InstallSnapshotReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()

	reply.Term = rf.currentTerm
	if args.Term < rf.currentTerm {
		return
	}
	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		rf.serverState = Follower
		rf.votedFor = -1
		rf.persist()
	}
	reply.Term = rf.currentTerm

	if args.LastIncludedIndex <= rf.lastIncludedIndex {
		rf.resetElectionTimeout()
		return
	}

	if args.LastIncludedIndex <= rf.getLastLogIndex() && rf.getTermAtIndex(args.LastIncludedIndex) == args.LastIncludedTerm {
		newLog := make([]LogEntry, 1)
		newLog[0] = LogEntry{Term: args.LastIncludedTerm, Command: nil}
		for i := args.LastIncludedIndex + 1; i <= rf.getLastLogIndex(); i++ {
			newLog = append(newLog, rf.getEntryAtIndex(i))
		}
		rf.log = newLog
	} else {
		rf.log = make([]LogEntry, 1)
		rf.log[0] = LogEntry{Term: args.LastIncludedTerm, Command: nil}
	}

	rf.lastIncludedIndex = args.LastIncludedIndex
	rf.lastIncludedTerm = args.LastIncludedTerm

	if rf.commitIndex < rf.lastIncludedIndex {
		rf.commitIndex = rf.lastIncludedIndex
	}
	if rf.lastApplied < rf.lastIncludedIndex {
		rf.lastApplied = rf.lastIncludedIndex
	}

	rf.snapshotData = make([]byte, len(args.Snapshot))
	copy(rf.snapshotData, args.Snapshot)
	rf.persist()

	msg := raftapi.ApplyMsg{
		CommandValid:  false,
		SnapshotValid: true,
		Snapshot:      args.Snapshot,
		SnapshotTerm:  rf.lastIncludedTerm,
		SnapshotIndex: rf.lastIncludedIndex,
	}
	rf.mu.Unlock()
	if rf.killed() {
		return
	}
	rf.applyCh <- msg
	rf.mu.Lock()

	rf.resetElectionTimeout()
}
func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
    // rogorc weria papershi Reply false if term < currentTerm (§5.1)
	if args.LeaderTerm < rf.currentTerm {
		reply.CurrentTerm = rf.currentTerm
		reply.Success = false
		return
	}

	if args.LeaderTerm > rf.currentTerm {
		rf.currentTerm = args.LeaderTerm
		rf.serverState = Follower
		rf.votedFor = -1
		rf.persist()
	}

	rf.resetElectionTimeout()
	reply.CurrentTerm = rf.currentTerm

	if args.PreviousLogIndex < rf.lastIncludedIndex {
		reply.Success = false
		reply.ConflictIndex = rf.lastIncludedIndex + 1
		reply.ConflictTerm = -1
		return
	}

	if args.PreviousLogIndex > rf.getLastLogIndex() {
		reply.Success = false
		reply.ConflictIndex = rf.getLastLogIndex() + 1
		reply.ConflictTerm = -1
		return
	}

	if args.PreviousLogIndex > 0 && rf.getTermAtIndex(args.PreviousLogIndex) != args.PreviousLogTerm {
		reply.Success = false
		reply.ConflictTerm = rf.getTermAtIndex(args.PreviousLogIndex)
		
		conflictIdx := args.PreviousLogIndex
		// amit vedzebt confliqti sadaa
		for conflictIdx > 0 && rf.getTermAtIndex(conflictIdx) == reply.ConflictTerm {
			conflictIdx--
		}
		reply.ConflictIndex = conflictIdx + 1
		return
	}

	for i, entry := range args.Entries {
		logIndex := args.PreviousLogIndex + 1 + i
		if logIndex <= rf.getLastLogIndex() {
			if rf.getTermAtIndex(logIndex) != entry.Term {
				
				cut := logIndex - rf.lastIncludedIndex
				if cut < 1 {
					cut = 1
				}
				rf.log = rf.log[:cut]
				rf.log = append(rf.log, entry)
			}
		} else {
			rf.log = append(rf.log, entry)
		}
	}
	rf.persist()

	if args.LeaderCommitIndex > rf.commitIndex {
		if args.LeaderCommitIndex < rf.getLastLogIndex() {
			rf.commitIndex = args.LeaderCommitIndex
		} else {
			rf.commitIndex = rf.getLastLogIndex()
		}
	}

	reply.Success = true
}

// example code to send a RequestVote RPC to a server.
// server is the index of the target server in rf.peers[].
// expects RPC arguments in args.
// fills in *reply with RPC reply, so caller should
// pass &reply.
// the types of the args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers).
//
// The labrpc package simulates a lossy network, in which servers
// may be unreachable, and in which requests and replies may be lost.
// Call() sends a request and waits for a reply. If a reply arrives
// within a timeout interval, Call() returns true; otherwise
// Call() returns false. Thus Call() may not return for a while.
// A false return can be caused by a dead server, a live server that
// can't be reached, a lost request, or a lost reply.
//
// Call() is guaranteed to return (perhaps after a delay) *except* if the
// handler function on the server side does not return.  Thus there
// is no need to implement your own timeouts around Call().
//
// look at the comments in ../labrpc/labrpc.go for more details.
//
// if you're having trouble getting RPC to work, check that you've
// capitalized all field names in structs passed over RPC, and
// that the caller passes the address of the reply struct with &, not
// the struct itself.
func (rf *Raft) sendRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
	return ok
}

func (rf *Raft) sendAppendEntries(server int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	ok := rf.peers[server].Call("Raft.AppendEntries", args, reply)
	return ok
}

func (rf *Raft) sendInstallSnapshot(server int, args *InstallSnapshotArgs, reply *InstallSnapshotReply) bool {
	ok := rf.peers[server].Call("Raft.InstallSnapshot", args, reply)
	return ok
}


// the service using Raft (e.g. a k/v server) wants to start
// agreement on the next command to be appended to Raft's log. if this
// server isn't the leader, returns false. otherwise start the
// agreement and return immediately. there is no guarantee that this
// command will ever be committed to the Raft log, since the leader
// may fail or lose an election. even if the Raft instance has been killed,
// this function should return gracefully.
//
// the first return value is the index that the command will appear at
// if it's ever committed. the second return value is the current
// term. the third return value is true if this server believes it is
// the leader.
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	index := -1
	term := -1
	isLeader := true

	rf.mu.Lock()
	defer rf.mu.Unlock()

	if rf.serverState != Leader {
		return index, term, false
	}

	isLeader = true
	term = rf.currentTerm
	
	newEntry := LogEntry{
		Term: rf.currentTerm,
		Command: command,
	}
	rf.log = append(rf.log, newEntry)
	rf.persist()
	index = rf.getLastLogIndex()

	return index, term, isLeader
}

// the tester doesn't halt goroutines created by Raft after each test,
// but it does call the Kill() method. your code can use killed() to
// check whether Kill() has been called. the use of atomic avoids the
// need for a lock.
//
// the issue is that long-running goroutines use memory and may chew
// up CPU time, perhaps causing later tests to fail and generating
// confusing debug output. any goroutine with a long-running loop
// should call killed() to check whether it should stop.
func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
	// Your code here, if desired.
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

func (rf *Raft) applier() {
	for rf.killed() == false {
		time.Sleep(10 * time.Millisecond)
		
		rf.mu.Lock()
		
		for rf.lastApplied < rf.commitIndex {
			if rf.killed() {
				rf.mu.Unlock()
				return
			}
			rf.lastApplied++
			if rf.lastApplied <= rf.lastIncludedIndex {
				continue
			}
			msg := raftapi.ApplyMsg{
				CommandValid: true,
				Command: rf.getEntryAtIndex(rf.lastApplied).Command,
				CommandIndex: rf.lastApplied,
			}
			if rf.killed() {
				rf.mu.Unlock()
				return
			}
			rf.mu.Unlock()
			rf.applyCh <- msg
			rf.mu.Lock()
		}
		
		rf.mu.Unlock()
	}
}

func (rf *Raft) ticker() {
	for rf.killed() == false {

		// Your code here (3A)
		// Check if a leader election should be started.
        
		time.Sleep(10 * time.Millisecond)

		rf.mu.Lock()
		
		if rf.serverState != Leader {
			// tu ver miigo hearbeat mashin tviton iwyebs axal elections
			if time.Now().After(rf.electionTimeoutDeadline) {
				rf.startElectionProcess()
				rf.mu.Unlock()
				continue
			}
		}

		if rf.serverState == Leader {
			timeSinceLastHeartbeat := time.Now().Sub(rf.lastHeartbeatTime)
			if timeSinceLastHeartbeat >= 120*time.Millisecond {
				rf.lastHeartbeatTime = time.Now()
				rf.sendHeartbeatsToAllPeers()
			}
		}

		rf.mu.Unlock()
	}
}

func (rf *Raft) resetElectionTimeout() {
	//rogorc weria election timeout larger than the paper's 150 to 300 milliseconds
	electionTimeoutMin := 400
	electionTimeoutMax := 800
	randomTimeout := electionTimeoutMin + rand.Intn(electionTimeoutMax-electionTimeoutMin)
	rf.electionTimeoutDeadline = time.Now().Add(time.Duration(randomTimeout) * time.Millisecond)
}

func (rf *Raft) getLastLogIndex() int {
	return rf.lastIncludedIndex + len(rf.log) - 1
}

func (rf *Raft) getLastLogTerm() int {
	lastIndex := rf.getLastLogIndex()
	if lastIndex == rf.lastIncludedIndex {
		return rf.lastIncludedTerm
	}
	return rf.getTermAtIndex(lastIndex)
}

func (rf *Raft) checkIfCandidateLogIsUpToDate(candidateLastLogIndex int, candidateLastLogTerm int) bool {
	myLastLogIndex := rf.getLastLogIndex()
	myLastLogTerm := rf.getLastLogTerm()

	if candidateLastLogTerm > myLastLogTerm {
		return true
	} else if candidateLastLogTerm == myLastLogTerm {
		if candidateLastLogIndex >= myLastLogIndex {
			return true
		} else {
			return false
		}
	} else {
		return false
	}
}

func (rf *Raft) getTermAtIndex(index int) int {
	if index == rf.lastIncludedIndex {
		return rf.lastIncludedTerm
	}
	if index < rf.lastIncludedIndex || index > rf.getLastLogIndex() {
		return -1
	}
	return rf.log[index-rf.lastIncludedIndex].Term
}

func (rf *Raft) getEntryAtIndex(index int) LogEntry {
	return rf.log[index-rf.lastIncludedIndex]
}

func (rf *Raft) startElectionProcess() {
	rf.serverState = Candidate
	rf.currentTerm = rf.currentTerm + 1
	rf.votedFor = rf.me
	rf.persist()
	rf.resetElectionTimeout()
	rf.votesReceivedInCurrentTerm = 1

	currentTermForElection := rf.currentTerm
	candidateIdForElection := rf.me
	lastLogIndexForElection := rf.getLastLogIndex()
	lastLogTermForElection := rf.getLastLogTerm()

	for peerIndex := 0; peerIndex < len(rf.peers); peerIndex++ {
		if peerIndex == rf.me {
			continue
		}

		go func(serverIndex int) {
			args := RequestVoteArgs{
				CandidateTerm:           currentTermForElection,
				CandidateId:             candidateIdForElection,
				LastLogIndexOfCandidate: lastLogIndexForElection,
				LastLogTermOfCandidate:  lastLogTermForElection,
			}
			reply := RequestVoteReply{}

			ok := rf.sendRequestVote(serverIndex, &args, &reply)

			if ok {
			    // aq vchekavt praqtikulad archevnebis drs ra moxda.
				rf.mu.Lock()
				defer rf.mu.Unlock()

				if rf.serverState != Candidate {
					return
				}
				if rf.currentTerm != currentTermForElection {
					return
				}

				if reply.CurrentTerm > rf.currentTerm {
					rf.currentTerm = reply.CurrentTerm
					rf.serverState = Follower
					rf.votedFor = -1
					rf.persist()
					rf.resetElectionTimeout()
					return
				}

				if reply.VoteGranted == true {
					// tu naxevarze 1igt meti xma gvaqvs anu lideri gavxdit
					rf.votesReceivedInCurrentTerm = rf.votesReceivedInCurrentTerm + 1
					majorityVotes := len(rf.peers)/2 + 1
					if rf.votesReceivedInCurrentTerm >= majorityVotes {
						rf.becomeLeader()
					}
				}
			}
		}(peerIndex)
	}
}

func (rf *Raft) becomeLeader() {
	if rf.serverState != Candidate {
		return
	}

	rf.serverState = Leader
	rf.lastHeartbeatTime = time.Now()
	
	rf.nextIndex = make([]int, len(rf.peers))
	rf.matchIndex = make([]int, len(rf.peers))
	for i := 0; i < len(rf.peers); i++ {
		rf.nextIndex[i] = rf.getLastLogIndex() + 1
		rf.matchIndex[i] = 0
	}
	
	rf.sendHeartbeatsToAllPeers()
}

func (rf *Raft) updateCommitIndex() {
	for n := rf.getLastLogIndex(); n > rf.commitIndex; n-- {
		if rf.getTermAtIndex(n) != rf.currentTerm {
			continue
		}
		
		replicationCount := 1
		for i := 0; i < len(rf.peers); i++ {
			if i == rf.me {
				continue
			}
			if rf.matchIndex[i] >= n {
				replicationCount++
			}
		}
		
		if replicationCount > len(rf.peers)/2 {
			rf.commitIndex = n
			break
		}
	}
}

func (rf *Raft) sendHeartbeatsToAllPeers() {
	for peerIndex := 0; peerIndex < len(rf.peers); peerIndex++ {
		if peerIndex == rf.me {
			continue
		}

		go func(serverIndex int) {
			for {
				rf.mu.Lock()
				if rf.serverState != Leader {
					rf.mu.Unlock()
					return
				}

				nextIdx := rf.nextIndex[serverIndex]
				if nextIdx <= rf.lastIncludedIndex && rf.snapshotData != nil {
					argsSnap := InstallSnapshotArgs{
						Term: rf.currentTerm,
						LeaderId: rf.me,
						LastIncludedIndex: rf.lastIncludedIndex,
						LastIncludedTerm: rf.lastIncludedTerm,
						Snapshot: rf.snapshotData,
					}
					currentTermForSnapshot := rf.currentTerm
					rf.mu.Unlock()
					replySnap := InstallSnapshotReply{}
					okSnap := rf.sendInstallSnapshot(serverIndex, &argsSnap, &replySnap)
					if okSnap {
						rf.mu.Lock()
						if rf.serverState != Leader {
							rf.mu.Unlock()
							return
						}
						if rf.currentTerm != currentTermForSnapshot {
							rf.mu.Unlock()
							return
						}
						if replySnap.Term > rf.currentTerm {
							rf.currentTerm = replySnap.Term
							rf.serverState = Follower
							rf.votedFor = -1
							rf.persist()
							rf.resetElectionTimeout()
							rf.mu.Unlock()
							return
						}
						rf.nextIndex[serverIndex] = rf.lastIncludedIndex + 1
						rf.matchIndex[serverIndex] = rf.lastIncludedIndex
						rf.mu.Unlock()
					} else {
						return
					}
					continue
				}
				prevLogIndex := nextIdx - 1
				prevLogTerm := rf.getTermAtIndex(prevLogIndex)

				entries := []LogEntry{}
				if nextIdx <= rf.getLastLogIndex() {
					start := nextIdx - rf.lastIncludedIndex
					if start < 1 {
						start = 1
					}
					entries = append(entries, rf.log[start:]...)
				}

				args := AppendEntriesArgs{
					LeaderTerm: rf.currentTerm,
					LeaderId: rf.me,
					PreviousLogIndex: prevLogIndex,
					PreviousLogTerm: prevLogTerm,
					Entries: entries,
					LeaderCommitIndex: rf.commitIndex,
				}
				
				currentTermForHeartbeat := rf.currentTerm
				rf.mu.Unlock()

				reply := AppendEntriesReply{}
				ok := rf.sendAppendEntries(serverIndex, &args, &reply)

				if ok {
					rf.mu.Lock()

					if rf.serverState != Leader {
						rf.mu.Unlock()
						return
					}
					if rf.currentTerm != currentTermForHeartbeat {
						rf.mu.Unlock()
						return
					}

					if reply.CurrentTerm > rf.currentTerm {
						rf.currentTerm = reply.CurrentTerm
						rf.serverState = Follower
						rf.votedFor = -1
						rf.persist()
						rf.resetElectionTimeout()
						rf.mu.Unlock()
						return
					}

					if reply.Success {
						rf.nextIndex[serverIndex] = prevLogIndex + 1 + len(entries)
						rf.matchIndex[serverIndex] = rf.nextIndex[serverIndex] - 1
						rf.updateCommitIndex()
						rf.mu.Unlock()
						return
					} else {
						if reply.ConflictTerm == -1 {
							rf.nextIndex[serverIndex] = reply.ConflictIndex
						} else {
							foundTerm := false
							for i := rf.getLastLogIndex(); i > rf.lastIncludedIndex; i-- {
								if rf.getTermAtIndex(i) == reply.ConflictTerm {
									rf.nextIndex[serverIndex] = i + 1
									foundTerm = true
									break
								}
							}
							if !foundTerm {
								rf.nextIndex[serverIndex] = reply.ConflictIndex
							}
						}
						if rf.nextIndex[serverIndex] < 1 {
							rf.nextIndex[serverIndex] = 1
						}
						rf.mu.Unlock()
					}
				} else {
					return
				}
			}
		}(peerIndex)
	}
}

// the service or tester wants to create a Raft server. the ports
// of all the Raft servers (including this one) are in peers[]. this
// server's port is peers[me]. all the servers' peers[] arrays
// have the same order. persister is a place for this server to
// save its persistent state, and also initially holds the most
// recent saved state, if any. applyCh is a channel on which the
// tester or service expects Raft to send ApplyMsg messages.
// Make() must return quickly, so it should start goroutines
// for any long-running work.
func Make(peers []*labrpc.ClientEnd, me int,
	persister *tester.Persister, applyCh chan raftapi.ApplyMsg) raftapi.Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.me = me
	rf.applyCh = applyCh

	// Your initialization code here (3A, 3B, 3C).
	rf.currentTerm = 0
	rf.votedFor = -1
	rf.log = make([]LogEntry, 1)
	rf.log[0] = LogEntry{Term: 0, Command: nil}

	rf.commitIndex = 0
	rf.lastApplied = 0

	rf.serverState = Follower
	rf.votesReceivedInCurrentTerm = 0
	rf.resetElectionTimeout()
	rf.lastIncludedIndex = 0
	rf.lastIncludedTerm = 0
	rf.snapshotData = nil

	// initialize from state persisted before a crash
	rf.readPersist(persister.ReadRaftState())

	// start ticker goroutine to start elections
	go rf.ticker()
	go rf.applier()

	return rf
}
